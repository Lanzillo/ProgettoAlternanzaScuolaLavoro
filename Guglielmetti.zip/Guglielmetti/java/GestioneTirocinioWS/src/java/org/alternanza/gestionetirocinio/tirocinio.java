/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.alternanza.gestionetirocinio;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author carlo
 */
@WebService(serviceName = "tirocinio")
public class tirocinio {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "VisualizzaStudente")
    public String VisualizzaStudente(@WebParam(name = "annoScolastico") String annoScolastico, @WebParam(name = "specializzazione") String specializzazione, @WebParam(name = "classe") int classe, @WebParam(name = "sezione") String sezione, @WebParam(name = "tipoStudente") String tipoStudente) {
        //TODO write your implementation code here:
        return Visualizza( annoScolastico, specializzazione, classe, sezione, tipoStudente);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "AbbinaTirocinioDesign")
    public String AbbinaTirocinioDesign(@WebParam(name = "rigaStudente") int rigaStudente, @WebParam(name = "azienda") String azienda) {
        //TODO write your implementation code here:
        return AbbinaTirocinio(rigaStudente,azienda);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "AbbinamentoDesigner")
    public boolean AbbinamentoDesigner(@WebParam(name = "rigaDitta") int rigaDitta, @WebParam(name = "rigaStudente") int rigaStudente) {
        //TODO write your implementation code here:
        return Abbinamento(rigaDitta,rigaStudente);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "AggiungiDesigner")
    public boolean AggiungiDesigner(@WebParam(name = "riga") int riga, @WebParam(name = "idStudente") int idStudente, @WebParam(name = "idDitta") int idDitta, @WebParam(name = "conversazione") int conversazione, @WebParam(name = "autorizzazione") boolean autorizzazione, @WebParam(name = "firma") String firma) {
        //TODO write your implementation code here:
        return Aggiungi(riga, idStudente, idDitta, conversazione, autorizzazione, firma);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Aggiungi2Design")
    public boolean Aggiungi2Design(@WebParam(name = "riga") int riga, @WebParam(name = "inizio") String inizio, @WebParam(name = "fine") String fine, @WebParam(name = "attivita") String attivita , @WebParam(name = "giorno") String giorno ) {
        //TODO write your implementation code here:
        return Aggiungi2( riga,  inizio,  fine,  attivita, giorno);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Aggiungi3Design")
    public boolean Aggiungi3Design(@WebParam(name = "riga") int riga ,@WebParam(name = "idStudente") int idStudente, @WebParam(name = "idDitta") int idDitta, @WebParam(name = "giorni") int giorni, @WebParam(name = "ore") int ore, @WebParam(name = "certificazione") Boolean certificazione, @WebParam(name = "questionarioAzienda") String questionarioAzienda, @WebParam(name = "questionarioStudente") String questionarioStudente, @WebParam(name = "questionarioGenitori") String questionarioGenitori, @WebParam(name = "valutazione") int valutazione) {
        //TODO write your implementation code here:
        return Aggiungi3( riga, idStudente, idDitta, giorni, ore, certificazione, questionarioAzienda, questionarioStudente, questionarioGenitori, valutazione);
    }
    
     @WebMethod(operationName = "Visualizza2")
    public String Visualizza2(@WebParam(name = "riga") int riga){
        //TODO write your implementation code here:
        return Visualizzamelo(riga);
    }
    private String Visualizza(String annoScolastico, String specializzazzione, int classe, String sezione, String tipoStudente){
        String temp="";
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            String sql = "SELECT * FROM alunno WHERE annoScolastico ='"+annoScolastico+"' AND specializzazzione='"+specializzazzione+"' AND classe='"+classe+"' AND stato='"+tipoStudente+"' AND sezione='"+sezione+"'";
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            
            ResultSet rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
                temp+=rs.getString("nome")+";"+rs.getString("cognome")+";"+rs.getString("stato")+";"+rs.getString("azienda")+";"+rs.getString("colore")+"-";
            }
              
        } catch (ClassNotFoundException ex) {
			
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
			
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return temp; 
    }
    private String AbbinaTirocinio(int rigaStudente,String azienda){ 
        String temp="";
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            String sql = "SELECT * FROM ditta";
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            
            ResultSet rs = stmt.executeQuery(sql);
            
            if(azienda.equals(""))
            {
                while(rs.next())
                {
                    temp+=rs.getString("denominazione")+";"+rs.getString("indirizzo")+";"+rs.getString("dataInizio")+";"+rs.getString("dataFine")+";"+rs.getInt("orario")+";"+rs.getString("competenze")+";"+rs.getString("attivita")+":";
                }
            }
            else
            {
                sql = "SELECT * FROM ditta WHERE denominazione='"+azienda+"'";
                rs = stmt.executeQuery(sql);
                while(rs.next())
                {
                    temp+=rs.getString("denominazione")+";"+rs.getString("indirizzo")+";"+rs.getString("dataInizio")+";"+rs.getString("dataFine")+";"+rs.getInt("orario")+";"+rs.getString("competenze")+";"+rs.getString("attivita")+":";
                }
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
			
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return temp;
    }
    private boolean Abbinamento(int rigaDitta,int rigaStudente){
        String temp="";
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            
            String sql = "SELECT * FROM ditta WHERE"+rigaDitta;
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            int idDitta=rs.getInt("id");
            sql = "SELECT * FROM studente WHERE"+rigaStudente;
            rs = stmt.executeQuery(sql);
            int idStudente=rs.getInt("id");
            sql="INSERT INTO tirocinio (idDitta,idStudente) VALUES ("+idDitta+","+idStudente+")";
            stmt.executeUpdate(sql);
            
            sql="SELECT * from studente WHERE "+rigaStudente;
            rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
                temp+=rs.getString("nome")+";"+rs.getString("cognome")+";"+rs.getString("stato")+";"+rs.getString("azienda")+"\r\n";
            }
            String[] vett= temp.split(";");
            sql="INSERT INTO studente ( nome, cognome, stato, azienda) VALUES ("+vett[0]+","+vett[1]+","+"assegnato"+","+vett[2]+")";
            
              
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true; 
    }
    private boolean Aggiungi(int riga,int idStudente,int idDitta,int conversazione,boolean autirazzazione,String firma){
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            
            String sql = "DELETE from tirocinio WHERE "+riga;
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            sql="INSERT INTO tirocinio ( idStudente, idDitta, conversazione, autirazzazione, firma) VALUES ("+idStudente+","+idDitta+","+conversazione+","+autirazzazione+","+firma+")";
            stmt.executeUpdate(sql);
            
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;  
    }
    private boolean Aggiungi2(int riga,String inizio,String fine,String attivita, String giorno) {
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            String sql="SELECT * from studente WHERE"+riga;
            ResultSet rs = stmt.executeQuery(sql);
            int idStudente=rs.getInt("id");
            
            sql="INSERT INTO incorso ( idStudente, inizio, fine, atttivita, firma , giorno) VALUES ("+idStudente+","+inizio+","+fine+","+attivita+","+giorno+")";
            stmt.executeUpdate(sql);
            
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;  
    }
    private boolean Aggiungi3(int riga, int idStudente, int idDitta ,int giorni,int ore,boolean certificazione,String questionarioAzienda,String questionarioStudente,String questionarioGenitori,int valutazione){
        try {
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            String sql="DELETE from tirociniConclusi WHERE"+riga;
            ResultSet rs = stmt.executeQuery(sql);
             idStudente=rs.getInt("id");
            
            sql="INSERT INTO tirociniConclusi ( idStudente, idDitta, giorni, ore, certificazione, questionarioAzienda,questionarioStudente,questionarioGenitori,valutazione) VALUES ("+idStudente+","+idDitta+","+giorni+","+ore+","+certificazione+","+questionarioAzienda+","+questionarioStudente+","+questionarioGenitori+","+valutazione+")";
            stmt.executeUpdate(sql);
            
             
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;  
    }
	/**
     * Web service operation
     */
   


private String Visualizzamelo(int riga)
{
    String temp="";
	 try {
             
            String JDBC_DRIVER = "com.mysql.jdbc.Driver";
            String DB_URL = "jdbc:mysql://localhost/AlternanzaScuolaLavoro";
            
            //  Database credentials
            String USER = "root";
            String PASS = "";
            
            //  Object for connection
            Connection conn = null;
            
            //  Object for SQL query
            Statement stmt = null;
            String sql = "SELECT * FROM tirociniConclusi WHERE idStudente ='"+riga+"'";
            
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();
            
            
            ResultSet rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
                temp+=rs.getString("giornate")+";"+rs.getString("ore")+";"+rs.getString("certificazione")+";"+rs.getString("questionarioAzienda")+";"+rs.getString("questionarioStudente")+";"+rs.getString("questionarioGenitori")+";"+rs.getString("valutazione")+";"+rs.getString("idStudente")+";"+rs.getString("idDitta")+"-";
            }
			  
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
			
        } catch (SQLException ex) {
            Logger.getLogger(tirocinio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return temp; 
}
}
