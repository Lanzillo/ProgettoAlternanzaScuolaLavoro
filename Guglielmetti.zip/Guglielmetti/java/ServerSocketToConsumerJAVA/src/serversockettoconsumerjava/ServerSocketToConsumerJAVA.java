
package serversockettoconsumerjava;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.*;

public class ServerSocketToConsumerJAVA extends Thread{
    private ServerSocket ss;
	//settaggio server con porta di comunicazione
	public ServerSocketToConsumerJAVA(int port) {
		try {
                    //instanziamento nuovo oggetto socket di tipo SERVER
			ss = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {

			try {
                            //thread per accettazione della connessione
				Socket clientSock = ss.accept();
                                System.out.println("Connessione accettata");
				saveFile(clientSock);
			} catch (IOException e) {
				e.printStackTrace();
			}

	}

	private void saveFile(Socket clientSock) throws IOException {
		DataInputStream dis = new DataInputStream(clientSock.getInputStream());
                //percorso assoluto salvataggio dei file spediti
                //inserire il path assoluto del salvataggio del file che si desidera ricevere
		FileOutputStream fos = new FileOutputStream("D:\\GuglielmettiLorenzo\\JAVA\\cattura.JPG");
		byte[] buffer = new byte[4096];
		
		int filesize = 15123; // salvo la dimensione dei file da inviare
		int read = 0;
		int totalRead = 0;
		int remaining = filesize;
                //lettura dei dati ricevuti
                System.out.println("Salvataggio dati...");
                while (dis.read(buffer) > 0) {
			fos.write(buffer);
		}
                //chiusura stream di dati 
		fos.close();
		dis.close();
                clientSock.close();
                System.out.println("fine");
	}
	
	public static void main(String[] args) {
            //setto la porta di comunicazione
            System.out.println("inizio");
		ServerSocketToConsumerJAVA fs = new ServerSocketToConsumerJAVA(1988);
		fs.start();
	}

}
