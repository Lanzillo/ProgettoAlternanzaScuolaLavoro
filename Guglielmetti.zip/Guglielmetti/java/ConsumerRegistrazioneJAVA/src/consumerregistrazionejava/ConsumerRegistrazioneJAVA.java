
package consumerregistrazionejava;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class ConsumerRegistrazioneJAVA {
private Socket s;
	
	public ConsumerRegistrazioneJAVA(String host, int port, String file) {
		try {
                    //creo nuovo oggetto socket di tipo CLIENT
			s = new Socket(host, port); //passaggio IP server e PORT di comunicazione
                        System.out.println("Connessione accettata");
			sendFile(file);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public void sendFile(String file) throws IOException {
            //dichiarazione stream di dati
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		FileInputStream fis = new FileInputStream(file);
		byte[] buffer = new byte[4096];
		//invio dei dati al server
                System.out.println("Invio file...");
		while (fis.read(buffer) > 0) {
			dos.write(buffer);
		}
		//chiusura stream
		fis.close();
		dos.close();
                System.out.println("fine");
	}
	
	public static void main(String[] args) {
            //creo nuovo oggetto CLIENT con indirizzo, porta e path assoluto per il file
            System.out.println("inizio");
            //inserire il path assouluto dell'immagine da inviare al server socket
		ConsumerRegistrazioneJAVA fc = new ConsumerRegistrazioneJAVA("localhost", 1988, "D:\\GuglielmettiLorenzo\\JAVA\\cattura.JPG");
	}
}
