package com.lorenzo.gestionetirocinio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StudenteAbbinato extends AppCompatActivity {

    EditText convenzione, autorizzazione, firma;
    Button conferma;
    CallWebService callWs = new CallWebService();
    Bundle bundle = this.getIntent().getExtras();
    String str = bundle.getString("abbinato");
    String vett[] = str.split("-");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informazioni_tirocinio);

        convenzione = (EditText) findViewById(R.id.editText4);
        autorizzazione = (EditText) findViewById(R.id.editText9);
        firma = (EditText) findViewById(R.id.editText10);
        conferma = (Button) findViewById(R.id.btnConferma);

        conferma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callWs.execute(CallWebService.METHOD_NAME_AGGIUNGI, vett[0] , vett[0], vett[1], convenzione.getText().toString(), autorizzazione.getText().toString(), firma.getText().toString());
                String s = callWs.getRisultato();
                if(s.equals("true"))
                Toast.makeText(getApplicationContext(), "Inserimento riuscito", Toast.LENGTH_SHORT).show();
                else
                Toast.makeText(getApplicationContext(), "Inserimento fallito", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
