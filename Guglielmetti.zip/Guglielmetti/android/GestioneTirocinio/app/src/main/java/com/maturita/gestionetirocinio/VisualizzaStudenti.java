package com.maturita.gestionetirocinio;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.ArrayList;
import java.util.List;

public class VisualizzaStudenti extends AppCompatActivity {

    TableLayout tabella;
    TableRow titolo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_studenti);

        tabella = (TableLayout) findViewById(R.id.tabella);
        titolo = (TableRow) findViewById(R.id.riga);

        List<String> lista = new ArrayList<String>();
        lista.add("12/03/2017;10:12;no");
        lista.add("04/02/2017;14:26;si");
        lista.add("26/01/2017;17:43;si");
        lista.add("15/02/2017;21:55;concluso");

        TableRow riga;
        EditText studente, tirocinio;
        for (String item : lista) {
            riga = new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            riga.setLayoutParams(lp);

            String[]vett =item.split(";", 3);

            studente = new EditText(this);
            tirocinio = new EditText(this);
            studente.setText(vett[0] + "  " + vett[1]);
            tirocinio.setText(vett[2]);
            tirocinio.setFocusable(false);
            tirocinio.setClickable(false);
            if(vett[2].equals("si"))
                tirocinio.setTextColor(Color.BLACK);
            else if (vett[2].equals("no")) {
                tirocinio.setTextColor(Color.RED);
            }
            else
                tirocinio.setTextColor(Color.GREEN);
            //studente.setWidth(0);
            //tirocinio.setWidth(0);
            tirocinio.setGravity(Gravity.CENTER);
            studente.setFocusable(false);
            studente.setClickable(false);
            riga.addView(studente);
            riga.addView(tirocinio);
            tabella.addView(riga);
        }
    }
}
