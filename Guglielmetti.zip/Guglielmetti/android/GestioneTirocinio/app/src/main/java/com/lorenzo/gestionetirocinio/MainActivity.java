package com.lorenzo.gestionetirocinio;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button view;
    Spinner anno, specializzazione, classe, sezione, tipo;
    TextView risultato;
    CallWebService callWs = new CallWebService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view = (Button) findViewById(R.id.btnVisualizza);
        anno = (Spinner) findViewById(R.id.spinnerAnno);
        specializzazione = (Spinner) findViewById(R.id.spinnerSpecializzazione);
        classe = (Spinner) findViewById(R.id.spinnerClasse);
        sezione = (Spinner) findViewById(R.id.spinnerSezione);
        tipo = (Spinner) findViewById(R.id.spinnerTipo);

        anno.setAdapter(null); //Resetto gli elementi dello spinner
        ArrayList<String> list = new ArrayList<String> ();
        list.add("2015/2016");
        list.add("2016/2017");
        ArrayAdapter<String> adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        anno.setAdapter(adp);

        tipo.setAdapter(null); //Resetto gli elementi dello spinner
        list = new ArrayList<String> ();
        list.add("Già abbianati");
        list.add("Non abbinati");
        list.add("Entrambi");
        adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        tipo.setAdapter(adp);

        classe.setAdapter(null); //Resetto gli elementi dello spinner
        list = new ArrayList<String> ();
        list.add("3");
        list.add("4");
        list.add("5");
        adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        classe.setAdapter(adp);

        sezione.setAdapter(null); //Resetto gli elementi dello spinner
        list = new ArrayList<String> ();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");
        adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        sezione.setAdapter(adp);

        specializzazione.setAdapter(null); //Resetto gli elementi dello spinner
        list = new ArrayList<String> ();
        list.add("Informatica");
        list.add("Meccanica");
        list.add("Chimica");
        list.add("Scientifico");
        list.add("Linguistico");
        adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        specializzazione.setAdapter(adp);



        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                callWs.setTextViewRisultato(risultato);
                callWs.execute(CallWebService.METHOD_NAME_ADD, anno.getSelectedItem().toString(), specializzazione.getSelectedItem().toString(),classe.getSelectedItem().toString(),sezione.getSelectedItem().toString(),tipo.getSelectedItem().toString());
                Intent intent = new Intent(getApplicationContext(), VisualizzaStudenti.class);
                Bundle bundle = new Bundle();
                //String str = edit_name.getText().toString();
                String str =  callWs.getRisultato();//"calcio;racapolanzo;macapomauri;vacapogullo;n";
                bundle.putString("name", str);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
