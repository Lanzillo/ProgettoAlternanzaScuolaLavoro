package com.lorenzo.gestionetirocinio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class StudenteTirocinioConcluso extends AppCompatActivity {

    Button conferma;
    Spinner giornate, ore, certificazione, questionarioAzienda, questionarioStudente, questionarioGenitori, valutazione;
    CallWebService callWs = new CallWebService();
    Bundle bundle = this.getIntent().getExtras();
    String str = bundle.getString("concluso");
    String vett[] = str.split("_");
    String vett2[] = vett[0].split("-");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studente_tirocinio_concluso);

        giornate = (Spinner) findViewById(R.id.spinnerGiornate);
        ore = (Spinner) findViewById(R.id.spinnerOraFine);
        certificazione = (Spinner) findViewById(R.id.spinnerOraInizio);
        questionarioAzienda = (Spinner) findViewById(R.id.spinnerQuestionatrioAzienda);
        questionarioStudente = (Spinner) findViewById(R.id.spinnerQuestionatrioStudente);
        questionarioGenitori = (Spinner) findViewById(R.id.spinnerQuestionatrioGenitori);
        valutazione = (Spinner) findViewById(R.id.spinnerValutazione);
        conferma = (Button) findViewById(R.id.btnConferma);

        List<String> lista = new ArrayList<String>();
        List<String> lista1 = new ArrayList<String>();
        List<String> lista2 = new ArrayList<String>();
        List<String> lista3 = new ArrayList<String>();
        List<String> lista4 = new ArrayList<String>();
        List<String> lista5 = new ArrayList<String>();
        List<String> lista6 = new ArrayList<String>();
        for(int i = 0; i < vett2.length; i++)
        {
            String vett3[] = vett2[i].split(";");
            lista.add(vett3[0]);
            lista1.add(vett3[1]);
            lista2.add(vett3[2]);
            lista3.add(vett3[3]);
            lista4.add(vett3[4]);
            lista5.add(vett3[5]);
            lista6.add(vett3[6]);

        }
        giornate.setAdapter(null);
        ArrayAdapter<String> adp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista);
        adp.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        giornate.setAdapter(adp);

        ore.setAdapter(null);
        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista1);
        adp1.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        ore.setAdapter(adp1);

        certificazione.setAdapter(null);
        ArrayAdapter<String> adp2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista2);
        adp2.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        certificazione.setAdapter(adp2);

        questionarioAzienda.setAdapter(null);
        ArrayAdapter<String> adp3 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista3);
        adp3.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        questionarioAzienda.setAdapter(adp3);

        questionarioStudente.setAdapter(null);
        ArrayAdapter<String> adp4 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista4);
        adp4.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        questionarioStudente.setAdapter(adp4);

        questionarioGenitori.setAdapter(null);
        ArrayAdapter<String> adp5 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista5);
        adp5.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        questionarioGenitori.setAdapter(adp5);

        valutazione.setAdapter(null);
        ArrayAdapter<String> adp6 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, lista6);
        adp6.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
        valutazione.setAdapter(adp6);

        conferma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vett3[] = vett2[0].split(";");
                callWs.execute(CallWebService.METHOD_NAME_AGGIUNTA, vett[1], vett3[7], vett3[8], giornate.getSelectedItem().toString(), ore.getSelectedItem().toString(), certificazione.getSelectedItem().toString(), questionarioAzienda.getSelectedItem().toString(), questionarioStudente.getSelectedItem().toString(), questionarioGenitori.getSelectedItem().toString() ,valutazione.getSelectedItem().toString());
                String s = callWs.getRisultato();//passare la stringa ad actity dopo
                if(s.equals("true"))
                    Toast.makeText(getApplicationContext(), "modiifica riuscita", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), "modifica fallita", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
