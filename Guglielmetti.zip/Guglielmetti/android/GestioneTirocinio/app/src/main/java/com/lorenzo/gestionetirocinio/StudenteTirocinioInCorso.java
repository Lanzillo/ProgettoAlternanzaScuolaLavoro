package com.lorenzo.gestionetirocinio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StudenteTirocinioInCorso extends AppCompatActivity {

    Button conferma;
    EditText oraInizio, oraFine, attivita, giorno;
    CallWebService callWs = new CallWebService();
    Bundle bundle = this.getIntent().getExtras();
    String str = bundle.getString("abbinato");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studente_tirocinio_in_corso);

        oraInizio = (EditText) findViewById(R.id.editText11);
        oraFine = (EditText) findViewById(R.id.editText12);
        attivita = (EditText) findViewById(R.id.editText14);
        giorno = (EditText) findViewById(R.id.editText13);
        conferma = (Button) findViewById(R.id.btnConferma);



        conferma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callWs.execute(CallWebService.METHOD_NAME_AGGIUNGIAMO, str, oraInizio.getText().toString(),oraFine.getText().toString() , attivita.getText().toString(), giorno.getText().toString());
                String s = callWs.getRisultato();
                if(s.equals("true"))
                Toast.makeText(getApplicationContext(), "Inserimento riuscito", Toast.LENGTH_SHORT).show();
                else
                Toast.makeText(getApplicationContext(), "Inserimento fallito", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
