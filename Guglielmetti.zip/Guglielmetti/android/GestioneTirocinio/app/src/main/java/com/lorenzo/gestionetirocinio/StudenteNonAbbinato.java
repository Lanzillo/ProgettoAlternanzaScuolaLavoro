package com.lorenzo.gestionetirocinio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StudenteNonAbbinato extends AppCompatActivity {

    EditText denominazione, indirizzo, inizio, fine, orario;
    EditText competenze, attivita;
    Button abbina;
    CallWebService callWs = new CallWebService();
    Bundle bundle = this.getIntent().getExtras();
    String str = bundle.getString("nonAbbinato");
    String vett[] = str.split(":");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inserisci_tirocinio);
        String vett2[] = vett[0].split(";");
        denominazione = (EditText) findViewById(R.id.editText3);
        indirizzo = (EditText) findViewById(R.id.editText5);
        inizio = (EditText) findViewById(R.id.editText6);
        fine = (EditText) findViewById(R.id.editText7);
        orario = (EditText) findViewById(R.id.editText8);
        competenze = (EditText) findViewById(R.id.editCompetenze);
        attivita = (EditText) findViewById(R.id.editAttivita);
        abbina = (Button) findViewById(R.id.btnAbbina);

            denominazione.setText(vett2[0]);
            indirizzo.setText(vett2[1]);
            inizio.setText(vett2[2]);
            fine.setText(vett2[3]);
            orario.setText(vett2[4]);


        abbina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vett[] = str.split("-");

                callWs.execute(CallWebService.METHOD_NAME_LIST, vett[1] , denominazione.getText().toString());
                String s = callWs.getRisultato();//passare la stringa ad actity dopo
                if(s.equals("true"))
                Toast.makeText(getApplicationContext(), "Inserimento riuscito", Toast.LENGTH_SHORT).show();
                else
                Toast.makeText(getApplicationContext(), "Inserimento fallito", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
