package com.lorenzo.gestionetirocinio;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class VisualizzaStudenti extends AppCompatActivity {

    TableLayout tabella;
    TableRow titolo;
    TextView risultato;
    CallWebService callWs = new CallWebService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_studenti);

        tabella = (TableLayout) findViewById(R.id.tabella);
        titolo = (TableRow) findViewById(R.id.riga);
        Bundle bundle = this.getIntent().getExtras();
        String str = bundle.getString("name");
        String vett[] = str.split("-");
        List<String> lista = new ArrayList<String>();
        for (int i = 0; i < vett.length; i++)
            lista.add(vett[i]);

        TableRow riga;
        EditText studente;
        RadioButton radio;
        Button b = null, b2 = null;
        for (Iterator<String> i = lista.iterator(); i.hasNext(); ) {
            riga = new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            riga.setLayoutParams(lp);
            String text = i.next();
            String[] vettStudente = text.split(";");
            studente = new EditText(this);
            studente.setText(vettStudente[0]);
            studente.setTextSize(24);
            studente.setFocusable(false);
            studente.setClickable(false);
            if (vettStudente[4].equals("r")) {
                studente.setTextColor(Color.RED);
                studente.setTag("Non abbinato");
            } else if (vettStudente[4].equals("n")) {
                studente.setTextColor(Color.BLACK);
                studente.setTag("Abbinato");
            } else if (vettStudente[4].equals("m")) {
                studente.setTextColor(Color.rgb(185, 122, 87));//marrone
                studente.setTag("In corso");
            } else if (vettStudente[4].equals("v")) {
                studente.setTextColor(Color.GREEN);
                studente.setTag("Concluso");
            }
            b = new Button(this);
            b.setOnClickListener(mListener);
            b.setText("Clicca");
            b.setTextSize(18);
            b.setGravity(0);
            b2 = new Button(this);
            b2.setOnClickListener(mListener2);
            b2.setText("Elimina");
            b2.setTextSize(18);
            b2.setGravity(0);
            riga.addView(studente);
            riga.addView(b);
            tabella.addView(riga);
        }
    }

    private View.OnClickListener mListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            TableRow tr = (TableRow) v.getParent();
            View str = tr.getChildAt(0);
            EditText e = (EditText) tr.getChildAt(0);
            Toast.makeText(getApplicationContext(), e.getText().toString(), Toast.LENGTH_SHORT).show();

            String vettValori[] = e.getText().toString().split(";");
            if (e.getTag().equals("Non abbinato")) {
                callWs.execute(CallWebService.METHOD_NAME_LIST, tr.getChildCount() + "", e.getText().toString());
                String s = callWs.getRisultato();//passare la stringa ad actity dopo
                Intent intent = new Intent(getApplicationContext(), StudenteNonAbbinato.class);
                Bundle bundle = new Bundle();
                bundle.putString("nonAbbinato", s + "-" + tr.getChildCount());
                intent.putExtras(bundle);
                startActivity(intent);
            } else if (e.getTag().equals("Abbinato")) {
                Intent intent = new Intent(getApplicationContext(), StudenteAbbinato.class);
                Bundle bundle = new Bundle();
                bundle.putString("abbinato", tr.getChildCount() + "-" + vettValori[3]);
                intent.putExtras(bundle);
                startActivity(intent);
            } else if (e.getTag().equals("In corso")) {
                Intent intent = new Intent(getApplicationContext(), StudenteTirocinioInCorso.class);
                Bundle bundle = new Bundle();
                bundle.putString("inCorso", tr.getChildCount() + "");
                intent.putExtras(bundle);
                startActivity(intent);
            } else if (e.getTag().equals("Concluso")) {
                callWs.execute(CallWebService.METHOD_NAME_VISUALIZZA, tr.getChildCount() + "");
                String s = callWs.getRisultato();
                Intent intent = new Intent(getApplicationContext(), StudenteTirocinioConcluso.class);
                Bundle bundle = new Bundle();
                bundle.putString("concluso", s + "_" + tr.getChildCount());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        }
    };

    private View.OnClickListener mListener2 = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            TableRow tr = (TableRow) v.getParent();
            View str = tr.getChildAt(0);
            EditText e = (EditText) tr.getChildAt(0);
            if (e.getTag().equals("Non Abbinato") || e.getTag().equals("Abbinato")) {
                callWs.execute(CallWebService.METHOD_NAME_Elimina, tr.getChildCount() + "");
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        }

    };
}