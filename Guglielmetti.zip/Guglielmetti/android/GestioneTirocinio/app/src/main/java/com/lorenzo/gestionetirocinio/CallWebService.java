﻿package com.lorenzo.gestionetirocinio;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;

// AsyncTask problem with orientation https://androidresearch.wordpress.com/2013/05/10/dealing-with-asynctask-and-screen-orientation/


// Uso di AsyncTask https://androidresearch.wordpress.com/2012/03/17/understanding-asynctask-once-and-forever/

//  AsyncTask is a generic class, it uses 3 types: AsyncTask<Params, Progress, Result>.
//        Params – the input. what you pass to the AsyncTask
//        Progress – if you have any updates, passed to onProgressUpdate()
//        Result – the output. what returns doInBackground()
public class CallWebService extends AsyncTask<String, String, String> {

    // vettore dove memorizzare la lista dei valori restituiti dal web service
    private ArrayList<String> arraylist;

    // TextView dove visualizzare il risultato
    private TextView textViewRisultato;

    private String risultato;

    // URL corrispondente al web service
    public final static String URL = "http://localhost:8080/GestioneTirocinioWS/tirocinio";//url del web service
    public final static String NAMESPACE = "http://org.aternnza.gestionetirocinio/";

    // nome dell'operazione
    public final static String METHOD_NAME_LIST = "AbbinsTirocinioDesign";
    private static final String PARAMETER_VALUE_LIST1 = "rigaStudente";
    private static final String PARAMETER_VALUE_LIST2 = "azienda";

    // nome dell'operazione
    public final static String METHOD_NAME_ADD = "VisualizzaStudente";
    // nome dei parametri
    private static final String PARAMETER_NAME_ADD1 = "annoScolastico";
    private static final String PARAMETER_NAME_ADD2 = "specializzazione";
    private static final String PARAMETER_NAME_ADD3 = "classe";
    private static final String PARAMETER_NAME_ADD4 = "sezione";
    private static final String PARAMETER_NAME_ADD5 = "tipoStudente";

    public final static String METHOD_NAME_ABBINAMENTO = "AbbinamentoDesigner";
    private static final String PARAMETER_VALUE_ABBINAMENTO1 = "rigaStudente";
    private static final String PARAMETER_VALUE_ABBINAMENTO2 = "rigaDitta";

    public final static String METHOD_NAME_AGGIUNGI = "AggiungiDesigner";
    private static final String PARAMETER_VALUE_AGGIUNGI1 = "riga";
    private static final String PARAMETER_VALUE_AGGIUNGI2 = "idStudente";
    private static final String PARAMETER_VALUE_AGGIUNGI3 = "idDitta";
    private static final String PARAMETER_VALUE_AGGIUNGI4 = "conversazione";
    private static final String PARAMETER_VALUE_AGGIUNGI5 = "autorazzazione";
    private static final String PARAMETER_VALUE_AGGIUNGI6 = "firma";

    public final static String METHOD_NAME_AGGIUNGIAMO = "Aggiungi2Design";
    private static final String PARAMETER_VALUE_AGGIUNGIAMO1 = "riga";
    private static final String PARAMETER_VALUE_AGGIUNGIAMO2 = "inizio";
    private static final String PARAMETER_VALUE_AGGIUNGIAMO3 = "fine";
    private static final String PARAMETER_VALUE_AGGIUNGIAMO4 = "attivita";
    private static final String PARAMETER_VALUE_AGGIUNGIAMO5 = "giorno";

    public final static String METHOD_NAME_AGGIUNTA = "Aggiungi3Design";
    private static final String PARAMETER_VALUE_AGGIUNTA1 = "riga";
    private static final String PARAMETER_VALUE_AGGIUNTA2 = "giorni";
    private static final String PARAMETER_VALUE_AGGIUNTA3 = "ore";
    private static final String PARAMETER_VALUE_AGGIUNTA4 = "certificazione";
    private static final String PARAMETER_VALUE_AGGIUNTA5 = "questionarioAzienda";
    private static final String PARAMETER_VALUE_AGGIUNTA6 = "questionarioStudente";
    private static final String PARAMETER_VALUE_AGGIUNTA7 = "questionarioGenitori";
    private static final String PARAMETER_VALUE_AGGIUNTA8 = "valutazione";
    private static final String PARAMETER_VALUE_ID_STUDENTE= "idStudente";
    private static final String PARAMETER_VALUE_ID_DITTA = "idDitta";

    public final static String METHOD_NAME_Elimina = "Elimina";
    private static final String PARAMETER_VALUE_Elimina = "riga";

    public final static String METHOD_NAME_VISUALIZZA = "Visualizza2";
    private static final String PARAMETER_VALUE_VISUALIZZA1 = "id";

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }


    @Override
    protected String doInBackground(String... params) {
        String str;

        if (params[0].equals(METHOD_NAME_ADD)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_ADD;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_ADD);
            soapObject.addProperty(PARAMETER_NAME_ADD1, params[1]);
            soapObject.addProperty(PARAMETER_NAME_ADD2, params[2]);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_NAME_ADD3);
            propertyInfo.setValue(params[3]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            soapObject.addProperty(PARAMETER_NAME_ADD4, params[4]);
            soapObject.addProperty(PARAMETER_NAME_ADD5, params[5]);
            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (params[0].equals(METHOD_NAME_LIST)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_LIST;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_LIST);
            soapObject.addProperty(PARAMETER_VALUE_LIST1, params[2]);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_LIST2);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (params[0].equals(METHOD_NAME_ABBINAMENTO)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_ABBINAMENTO;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_ABBINAMENTO);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_ABBINAMENTO1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            PropertyInfo propertyInfo2 = new PropertyInfo();
            propertyInfo2.setName(PARAMETER_VALUE_ABBINAMENTO2);
            propertyInfo2.setValue(params[2]);
            propertyInfo2.setType(int.class);
            soapObject.addProperty(propertyInfo2);
            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (params[0].equals(METHOD_NAME_AGGIUNGI)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_AGGIUNGI;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_AGGIUNGI);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_AGGIUNGI1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            PropertyInfo propertyInfo2 = new PropertyInfo();
            propertyInfo2.setName(PARAMETER_VALUE_AGGIUNGI2);
            propertyInfo2.setValue(params[2]);
            propertyInfo2.setType(int.class);
            soapObject.addProperty(propertyInfo2);
            PropertyInfo propertyInfo3 = new PropertyInfo();
            propertyInfo3.setName(PARAMETER_VALUE_AGGIUNGI3);
            propertyInfo3.setValue(params[3]);
            propertyInfo3.setType(int.class);
            soapObject.addProperty(propertyInfo3);
            PropertyInfo propertyInfo4 = new PropertyInfo();
            propertyInfo4.setName(PARAMETER_VALUE_AGGIUNGI4);
            propertyInfo4.setValue(params[4]);
            propertyInfo4.setType(int.class);
            PropertyInfo propertyInfo5 = new PropertyInfo();
            propertyInfo5.setName(PARAMETER_VALUE_AGGIUNGI5);
            propertyInfo5.setValue(params[5]);
            propertyInfo5.setType(boolean.class);
            soapObject.addProperty(propertyInfo5);
            PropertyInfo propertyInfo6 = new PropertyInfo();
            propertyInfo6.setName(PARAMETER_VALUE_AGGIUNGI6);
            propertyInfo6.setValue(params[6]);
            propertyInfo6.setType(String.class);
            soapObject.addProperty(propertyInfo6);
            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (params[0].equals(METHOD_NAME_AGGIUNGIAMO)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_AGGIUNGIAMO;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_AGGIUNGIAMO);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_AGGIUNGIAMO1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            PropertyInfo propertyInfo2 = new PropertyInfo();
            propertyInfo2.setName(PARAMETER_VALUE_AGGIUNGIAMO2);
            propertyInfo2.setValue(params[2]);
            propertyInfo2.setType(String.class);
            soapObject.addProperty(propertyInfo2);
            PropertyInfo propertyInfo3 = new PropertyInfo();
            propertyInfo3.setName(PARAMETER_VALUE_AGGIUNGIAMO3);
            propertyInfo3.setValue(params[3]);
            propertyInfo3.setType(String.class);
            soapObject.addProperty(propertyInfo3);
            PropertyInfo propertyInfo4 = new PropertyInfo();
            propertyInfo4.setName(PARAMETER_VALUE_AGGIUNGIAMO4);
            propertyInfo4.setValue(params[4]);
            propertyInfo4.setType(String.class);
            soapObject.addProperty(propertyInfo4);
            PropertyInfo propertyInfo5 = new PropertyInfo();
            propertyInfo5.setName(PARAMETER_VALUE_AGGIUNGIAMO5);
            propertyInfo5.setValue(params[5]);
            propertyInfo5.setType(String.class);
            soapObject.addProperty(propertyInfo5);
            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (params[0].equals(METHOD_NAME_AGGIUNTA)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_AGGIUNTA;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_AGGIUNTA);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_AGGIUNTA1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);
            PropertyInfo propertyInfo9 = new PropertyInfo();
            propertyInfo9.setName(PARAMETER_VALUE_ID_STUDENTE);
            propertyInfo9.setValue(params[2]);
            propertyInfo9.setType(boolean.class);
            soapObject.addProperty(propertyInfo9);
            PropertyInfo propertyInfo10 = new PropertyInfo();
            propertyInfo10.setName(PARAMETER_VALUE_AGGIUNTA8);
            propertyInfo10.setValue(params[3]);
            propertyInfo10.setType(boolean.class);
            soapObject.addProperty(propertyInfo10);
            PropertyInfo propertyInfo2 = new PropertyInfo();
            propertyInfo2.setName(PARAMETER_VALUE_AGGIUNTA2);
            propertyInfo2.setValue(params[4]);
            propertyInfo2.setType(int.class);
            soapObject.addProperty(propertyInfo2);
            PropertyInfo propertyInfo3 = new PropertyInfo();
            propertyInfo3.setName(PARAMETER_VALUE_AGGIUNTA3);
            propertyInfo3.setValue(params[5]);
            propertyInfo3.setType(int.class);
            soapObject.addProperty(propertyInfo3);
            PropertyInfo propertyInfo4 = new PropertyInfo();
            propertyInfo4.setName(PARAMETER_VALUE_AGGIUNTA4);
            propertyInfo4.setValue(params[6]);
            propertyInfo4.setType(boolean.class);
            soapObject.addProperty(propertyInfo4);
            PropertyInfo propertyInfo5 = new PropertyInfo();
            propertyInfo5.setName(PARAMETER_VALUE_AGGIUNTA5);
            propertyInfo5.setValue(params[7]);
            propertyInfo5.setType(String.class);
            soapObject.addProperty(propertyInfo5);
            PropertyInfo propertyInfo6 = new PropertyInfo();
            propertyInfo6.setName(PARAMETER_VALUE_AGGIUNTA6);
            propertyInfo6.setValue(params[8]);
            propertyInfo6.setType(String.class);
            soapObject.addProperty(propertyInfo6);
            PropertyInfo propertyInfo7 = new PropertyInfo();
            propertyInfo7.setName(PARAMETER_VALUE_AGGIUNTA7);
            propertyInfo7.setValue(params[9]);
            propertyInfo7.setType(String.class);
            soapObject.addProperty(propertyInfo7);
            PropertyInfo propertyInfo8 = new PropertyInfo();
            propertyInfo8.setName(PARAMETER_VALUE_AGGIUNTA8);
            propertyInfo8.setValue(params[10]);
            propertyInfo8.setType(boolean.class);
            soapObject.addProperty(propertyInfo8);

            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
            else if (params[0].equals(METHOD_NAME_Elimina)) {
                String SOAP_ACTION = NAMESPACE + METHOD_NAME_Elimina;
                SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_Elimina);
                PropertyInfo propertyInfo = new PropertyInfo();
                propertyInfo.setName(PARAMETER_VALUE_Elimina);
                propertyInfo.setValue(params[1]);
                propertyInfo.setType(int.class);
                soapObject.addProperty(propertyInfo);
                Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(soapObject);
                HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
                try {
                    httpTransportSE.call(SOAP_ACTION, envelope);
                    SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                    str = soapPrimitive.toString();
                    Log.i("com.example.samplews", "Risultato -------------- " + str);
                    return str;
                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
        else if (params[0].equals(METHOD_NAME_VISUALIZZA)) {
            String SOAP_ACTION = NAMESPACE + METHOD_NAME_VISUALIZZA;
            SoapObject soapObject = new SoapObject(NAMESPACE, METHOD_NAME_VISUALIZZA);
            PropertyInfo propertyInfo = new PropertyInfo();
            propertyInfo.setName(PARAMETER_VALUE_VISUALIZZA1);
            propertyInfo.setValue(params[1]);
            propertyInfo.setType(int.class);
            soapObject.addProperty(propertyInfo);

            Log.i("com.example.samplews", "Request Value -> " + soapObject.toString());
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(soapObject);
            HttpTransportSE httpTransportSE = new HttpTransportSE(URL);
            try {
                httpTransportSE.call(SOAP_ACTION, envelope);
                SoapPrimitive soapPrimitive = (SoapPrimitive) envelope.getResponse();
                str = soapPrimitive.toString();
                Log.i("com.example.samplews", "Risultato -------------- " + str);
                return str;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    // http://stackoverflow.com/questions/12575068/how-to-get-the-result-of-onpostexecute-to-main-activity-because-asynctask-is-a

    @Override
    protected void onPostExecute(String esito) {
        super.onPostExecute(esito);

        // richiamato al termine della chiamata al web service
        // il parametro esito è il valore ritornato da doInBackground()

        if (esito != null) {
            if (esito.equals("lista")) {

            } else {
                risultato = esito;
                textViewRisultato.setText("Risultato " + esito);
            }
        }
    }

    public String getRisultato() {
        return risultato;
    }

    public void setRisultato(String risultato) {
        this.risultato = risultato;
    }

    public void setTextViewRisultato(TextView tv) {
        textViewRisultato = tv;
    }

}